<h1><?php echo link_to('Symfony楽団公式サイト', 'homepage') ?></h1>
